
import com.mysql.cj.xdevapi.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class Inventory {
    private Map<Integer, Product> products;

    public Inventory() {
        products = new HashMap<>();
    }

    public void addProduct(Product product) {
        products.put(product.getProductId(), product);
    }

    public void removeProduct(int productId) throws ProductNotFoundException {
        if (!products.containsKey(productId)) {
            throw new ProductNotFoundException("Product not found with ID: " + productId);
        }
        products.remove(productId);
    }

    public void displayAllProducts() {
        System.out.println("Inventory:");
        products.values().stream().forEach((product) -> {
            System.out.println(product.getProductId() + ". " + product.getProductName() +
                    " - Category: " + product.getCategory() +
                    ", Price: " + product.getPrice() +
                    ", Quantity: " + product.getQuantity() +
                    ", Available Stock: " + product.getAvailableStock());
        });
    }

    public Product searchProductByName(String productName) {
        for (Product product : products.values()) {
            if (product.getProductName().equalsIgnoreCase(productName)) {
                return product;
            }
        }
        return null; // Product not found
    }

    public List<Product> searchProductByCategory(String category) {
        List<Product> result = new ArrayList<>();
        for (Product product : products.values()) {
            if (product.getCategory().equalsIgnoreCase(category)) {
                result.add(product);
            }
        }
        return result;
    }



    private Map<Integer, Product> productMap = new HashMap<>();
    private Connection connection;

    

    public void storeProductInDatabase(Product product) {
        establishConnection();

        String query = "INSERT INTO products (productId, productName, category, price, quantity, availableStock) VALUES (?, ?, ?, ?, ?, ?)";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, product.getProductId());
            preparedStatement.setString(2, product.getProductName());
            preparedStatement.setString(3, product.getCategory());
            preparedStatement.setDouble(4, product.getPrice());
            preparedStatement.setInt(5, product.getQuantity());
            preparedStatement.setInt(6, product.getAvailableStock());

            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeConnection();
        }
    }

    public Product retrieveProductFromDatabase(int productId) {
        establishConnection();

        String query = "SELECT * FROM products WHERE productId = ?";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, productId);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    return new Product(
                            resultSet.getInt("productId"),
                            resultSet.getString("productName"),
                            resultSet.getString("category"),
                            resultSet.getDouble("price"),
                            resultSet.getInt("quantity"),
                            resultSet.getInt("availableStock")
                    );
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeConnection();
        }

        return null; // Return null if the product is not found
    }

    public void updateProductInformationInDatabase(int productId, double newPrice, int newQuantity, int newAvailableStock) {
        establishConnection();

        String query = "UPDATE products SET price = ?, quantity = ?, availableStock = ? WHERE productId = ?";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setDouble(1, newPrice);
            preparedStatement.setInt(2, newQuantity);
            preparedStatement.setInt(3, newAvailableStock);
            preparedStatement.setInt(4, productId);

            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeConnection();
        }
    }

    // Other methods...

    
       private void establishConnection() {
    String jdbcUrl = "jdbc:mysql://localhost:3306/postgresql";
    String username = "root";
    String password = " ";

    try {
        // Load the JDBC driver
        Class.forName("com.mysql.cj.jdbc.Driver");

        // Establish the connection
        connection = DriverManager.getConnection(jdbcUrl, username, password);
    } catch (ClassNotFoundException | SQLException e) {
        e.printStackTrace();
        // Handle the exception appropriately in your application
    }
}

    

    private void closeConnection() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }




    // ... existing code ...

    void updateProductInformation(int productId, double newPrice, int newQuantity) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}

    
    
    
