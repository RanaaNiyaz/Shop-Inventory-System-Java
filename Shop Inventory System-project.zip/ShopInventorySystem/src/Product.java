// Custom Exception for selling a product with no available stock
class InsufficientStockException extends Exception {
    public InsufficientStockException(String message) {
        super(message);
    }
}

// Custom Exception for attempting to remove a product that is not in the inventory
class ProductNotFoundException extends Exception {
    public ProductNotFoundException(String message) {
        super(message);
    }
}

class Product {
    private int productId;
    private String productName;
    private String category;
    private double price;
    private int quantity;
    private int availableStock;

    public Product(int productId, String productName, String category, double price, int quantity) {
        this.productId = productId;
        this.productName = productName;
        this.category = category;
        this.price = price;
        this.quantity = quantity;
        this.availableStock = quantity;
    }

    Product(int productId, String productName, String category, double price, int quantity, int availableStock) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    // Getters and setters

    public int getProductId() {
        return productId;
    }

    public String getProductName() {
        return productName;
    }

    public String getCategory() {
        return category;
    }

    public double getPrice() {
        return price;
    }

    public int getQuantity() {
        return quantity;
    }

    public int getAvailableStock() {
        return availableStock;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
        this.availableStock = quantity; // Initially, available stock is set to total quantity
    }

    // Method to update available stock after selling a product
    public void sell(int quantitySold) throws InsufficientStockException {
        if (quantitySold > availableStock) {
            throw new InsufficientStockException("Insufficient stock for product: " + productName);
        }
        availableStock -= quantitySold;
    }
    
}
