
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ShopInventorySystem {
    public static void main(String[] args) {
        Inventory inventory = new Inventory();
        Scanner scanner = new Scanner(System.in);

        // Adding sample products
        Product product1 = new Product(1, "Laptop", "Electronics", 999.99, 10);
        Product product2 = new Product(2, "Chair", "Furniture", 49.99, 20);
        Product product3 = new Product(3, "Headphones", "Electronics", 79.99, 15);

        // Adding products to the inventory
        inventory.addProduct(product1);
        inventory.addProduct(product2);
        inventory.addProduct(product3);

        while (true) {
            // Display menu
            System.out.println("\n1. Display All Products");
            System.out.println("2. Search for a Product by Name");
            System.out.println("3. Search for Products by Category");
            System.out.println("4. Update Product Information");
            System.out.println("5. Remove a Product");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume the newline character

            switch (choice) {
                case 1:
                    inventory.displayAllProducts();
                    break;
                case 2:
                    System.out.print("Enter product name: ");
                    String productName = scanner.nextLine();
                    Product foundProduct = inventory.searchProductByName(productName);
                    if (foundProduct != null) {
                        System.out.println("Product found: " + foundProduct.getProductName());
                    } else {
                        System.out.println("Product not found.");
                    }
                    break;
                case 3:
                    System.out.print("Enter category: ");
                    String category = scanner.nextLine();
                    List<Product> productsByCategory = inventory.searchProductByCategory(category);
                    System.out.println("Products in category " + category + ":");
                    for (Product product : productsByCategory) {
                        System.out.println(product.getProductName());
                    }
                    break;
                case 4:
                    System.out.print("Enter product ID to update: ");
                    int productId = scanner.nextInt();
                    System.out.print("Enter new price: ");
                    double newPrice = scanner.nextDouble();
                    System.out.print("Enter new quantity: ");
                    int newQuantity = scanner.nextInt();
                    inventory.updateProductInformation(productId, newPrice, newQuantity);
                    System.out.println("Product information updated successfully.");
                    break;
                case 5:
                    try {
                        System.out.print("Enter product ID to remove: ");
                        int removeProductId = scanner.nextInt();
                        inventory.removeProduct(removeProductId);
                        System.out.println("Product removed successfully.");
                    } catch (ProductNotFoundException e) {
                        System.out.println("Error: " + e.getMessage());
                    }
                    break;
                case 6:
                    System.out.println("Exiting the system. Thank you!");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    
  
 


        
}
}
    
    
    

